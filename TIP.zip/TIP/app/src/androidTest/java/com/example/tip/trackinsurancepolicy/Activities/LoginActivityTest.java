package com.example.tip.trackinsurancepolicy.Activities;

import android.support.constraint.ConstraintLayout;
import android.support.test.rule.ActivityTestRule;

import com.example.tip.trackinsurancepolicy.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoginActivityTest {

    public ActivityTestRule<LoginActivity> mActivityTestRule = new ActivityTestRule<LoginActivity>(LoginActivity.class);

    LoginActivity lact = null;

    @Before
    public void setUp() throws Exception {
        //getting the activity into the object before the tests start
        lact = mActivityTestRule.getActivity();
    }

    @Test
    public void testActivity(){
        //get the main constraint layout
        ConstraintLayout view = (ConstraintLayout)lact.findViewById(R.id.loginConstraintLayout);
        //check whether it it initialized or not
        assertNotNull(view);

        /*
        * Similarly make functions with annotations as @Test
        * and inside it save any one element from the activity - layout element or any data structure like arrayList that you may have used and so on
        * and assertNotNull
        *
        * for Testing select all text in this activity by 'Ctrl+A'
        * and right click and select run TestActivity() option and keep your phone connected like you keep while installing app
        * tests will automatically run and you can take screenshots !git
        * */
    }

    @After
    public void tearDown() throws Exception {
        lact = null;
        //The object will become null after the tests are finished
    }
}